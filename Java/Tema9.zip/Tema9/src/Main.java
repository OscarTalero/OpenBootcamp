public class Main {
    public static void main(String[] args) {
    Cliente cliente = new Cliente();
    cliente.setNombre("Jhon");
    System.out.println("El nombre del cliente es: " + cliente.getNombre());
    cliente.setEdad(30);
    System.out.println("Su edad es: " + cliente.getEdad() + " anhos");
    cliente.setTelefono(345789);
    System.out.println("Su numero de telefono es: " + cliente.getTelefono());
    cliente.setCredito(1000);
    System.out.println("Su credito es de: " + cliente.getCredito());
    Trabajador trabajador = new Trabajador();
    trabajador.setNombre("Adam");
    System.out.println("El nombre del trabajador es: " + trabajador.getNombre());
    trabajador.setEdad(25);
    System.out.println("Su edad es: " + trabajador.getEdad() + " anhos");
    trabajador.setTelefono(987432);
    System.out.println("Su numero de telefono es: " + trabajador.getTelefono());
    trabajador.setSalario(2000);
    System.out.println("Su salario es de: " + trabajador.getSalario());

    }
}

class Persona{
    private int edad;
    private String nombre;
    private int telefono;

    public int getEdad() {
        return edad;
    }
    public void setEdad(int edad) {
        this.edad = edad;
    }
    public String getNombre() {
        return nombre;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public int getTelefono() {
        return telefono;
    }
    public void setTelefono(int telefono) {
        this.telefono = telefono;
    }
}

class Cliente extends Persona {
    private int credito;

    public void setCredito(int credito) {
        this.credito = credito;
    }
    public int getCredito() {
        return credito;
    }
}

class Trabajador extends Persona {
    private int salario;

    public void setSalario(int salario) {
        this.salario = salario;
    }
    public int getSalario() {
        return salario;
    }
}