public class Main {
    public static void main(String[] args) {
        int numeroif = 5;
        int numeroWhile = 3;
        String estacion = "INVIERNO";

        //Condicional if
        if (numeroif > 0) {
            System.out.println("El numero " + numeroif + " es positivo");
        }
        else if(numeroif < 0) {
            System.out.println("El numero " + numeroif + " es negativo");
        }
        else {
            System.out.println("El numero " + numeroif + " es cero" );
        }

        //Ciclo while
        while (numeroWhile < 3){
            numeroWhile++;
            System.out.println(numeroWhile);
        }

        //ciclo do while
        do {
            System.out.println(numeroWhile);
        }
        while (numeroWhile < 3);

        //ciclo for
        for (int numerofor =0; numerofor < 3; numerofor++){
            System.out.println(numerofor);
        }

        //switch
        switch (estacion){
            case "PRIMAVERA":
                System.out.println("Disfruta la Primavera");
                break;
            case "VERANO":
                System.out.println("Toma mucho liquido, es Verano");
                break;
            case "INVIERNO":
                System.out.println("Saca tu abrigo es Invierno");
                break;
            case "OTONHO":
                System.out.println("Se cen las hojas en Otonho");
                break;
            default:
                System.out.println("No existe la estacion " + estacion);
        }

    }
}