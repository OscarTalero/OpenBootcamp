package Inicio;

public class main {
    public static void main (String[] args) {

        suma(2,3,4);

        Coche micoche = new Coche();
        micoche.agregarPuerta();
        System.out.println("El numero de puertas ahora es :" + micoche.numeroPuertas);

    }

    public static void suma (int a, int b, int c) {
        int resultado = 0;
        resultado = a + b + c;
        System.out.println(resultado);
    }
}

class Coche {
    public int numeroPuertas = 2;

    public void agregarPuerta() {
        this.numeroPuertas++;

    }
}
