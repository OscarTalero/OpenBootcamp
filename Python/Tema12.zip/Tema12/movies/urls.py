from django.urls import include, path
from . import views

urlpatterns = [
    path('', views.index, name="index"),
    path('director/<int:id>', views.director, name='director'),
    path('movie_detail/<int:id>', views.movie_detail, name='movie_detail'),
]