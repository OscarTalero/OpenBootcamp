from unicodedata import name
from django.db import models

# Create your models here.
class Director(models.Model):
    name = models.CharField(max_length=20)
    last_name = models.CharField(max_length=20)

    def __str__(self):
        return self.name + ' ' + self.last_name 

class Movie(models.Model):
    title = models.CharField(max_length=50)
    director = models.ForeignKey('Director', on_delete=models.SET_NULL, null=True)
    anho = models.IntegerField()
    sinopsis = models.TextField(max_length=120)

    def __str__(self):
        return self.title
