from gc import get_objects
from django.shortcuts import get_object_or_404, render
from .models import Director, Movie

# Create your views here.

def index(request):
    directors = Director.objects.all()

    return render(
        request,
        'index.html',
        context={
            'directors' : directors
        })

def director(request, id):

    movies = Movie.objects.filter(director__id__exact=id)
    direct = Director.objects.filter(id__contains=id)

    return render(
        request,
        'director.html',
        context={
            'direct' : direct,
            'movies' : movies 
        })

def movie_detail(request, id):

    movie = Movie.objects.filter(id__contains=id)
    print(movie)
    return render(
        request,
        'movie_detail.html',
        context={
            'movie' : movie 
        })